var guitarApp = angular.module('guitarApp', ['ui.router']);
guitarApp.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/Home')

    $stateProvider
        .state('Home', {
            url: "/Home",
            templateUrl: "htmls/home.html",
            controller: "HomeCtrl"
        });
    $stateProvider
        .state('Purchase', {
            url: "/Purchase",
            templateUrl: "htmls/purchase.html",
            controller: "PurchaseCtrl"
        });
    $stateProvider
        .state('Confirm', {
            url: "/Confirm",
            templateUrl: "htmls/confirm.html",
            controller: "ConfirmCtrl"
        });
});
guitarApp.controller('HomeCtrl', ['$scope', '$http', '$state', 'x', function($scope, $http, $state, x) {
    $scope.guitars = [];
    $scope.index1 = 0;
    $scope.productI = true;
    $scope.shipI = true;
    $scope.custI = true;
    $scope.switchPoint = -1;
    $http.get('guitardata.json')
        .success(function(result) {
            $scope.guitars = result;
        });
    $scope.next = function() {
        if ($scope.index1 == 6) {
            $scope.index1 = 0;
        } else {
            $scope.index1 = $scope.index1 + 1;
        }

    }
    $scope.rotateF = function() {
        $scope.switchPoint = 8;
    }
    $scope.previous = function() {
        if ($scope.index1 == 0) {
            $scope.index1 = 6;
        } else {
            $scope.index1 = $scope.index1 - 1;
        }

    }
    $scope.toggle = function(value1) {
        var input1 = value1;

        if (input1 == "productInfo") {
            console.log(input1);
            $scope.productI = !$scope.productI;
        } else if (input1 == "shipInfo") {
            $scope.shipI = !$scope.shipI;
        } else if (input1 == "custRev") {
            $scope.custI = !$scope.custI;
        }
    }
    $scope.buy = function(ind) {
        x.iguitar = $scope.guitars[ind];
        $state.go('Purchase', {
            'id': ind
        });
    }


}]);
guitarApp.controller('PurchaseCtrl', ['$rootScope', '$scope', '$state', '$stateParams', 'x', 'shipping', function($rootScope, $scope, $state, $stateParams, x, shipping) {
    $scope.iguitar = x.iguitar;
    $scope.index = $stateParams.id;
    $scope.hideReview = true;

    $scope.review = function() {
        $scope.hideReview = false;
    }
    $scope.edit = function() {
        $scope.hideReview = true;
    }
    $scope.buyF = function() {
        shipping.firstname = $scope.firstname;
        shipping.lastname = $scope.lastname;
        shipping.address1 = $scope.address1;
        shipping.address2 = $scope.address2;
        shipping.city = $scope.city;
        shipping.state = $scope.state;
        shipping.zipcode = $scope.zipcode;
        shipping.phno = $scope.phno;
        shipping.email = $scope.email;
        $state.go('Confirm', {
            'id': 0
        });
    }



}]);
guitarApp.controller('ConfirmCtrl', ['$rootScope', '$scope', '$state', '$stateParams', 'x', 'shipping', function($rootScope, $scope, $state, $stateParams, x, shipping) {
    $scope.iguitar = x.iguitar;
    $scope.firstname = shipping.firstname;
    $scope.lastname = shipping.lastname;
    $scope.address1 = shipping.address1;
    $scope.address2 = shipping.address2;
    $scope.city = shipping.city;
    $scope.state = shipping.state;
    $scope.zipcode = shipping.zipcode;
    $scope.phno = shipping.phno;
    $scope.email = shipping.email;
    var price = $scope.iguitar;
    var price1 = price.price;
    var price2 = price.shipping_price;
    var price3 = price1 + price2;
    $scope.tax = ((price3 * 8) / 100);
    var finalPrice = ((price3 * 8) / 100) + price3;
    $scope.finalPrice = finalPrice;


    $scope.home = function() {
        $state.go('Home', {
            'id': 0
        });
    }
}]);
guitarApp.service('x', function() {
    this.iguitar = {};
});
guitarApp.service('shipping', function() {
    this.firstname = "";
});
guitarApp.directive("navigation1", function() {
    return {
        templateUrl: 'htmls/navbar.html'
    };

});
guitarApp.directive("footer", function() {
    return {
        template: '<div class="row footer"><center><img src="images/logo2.png"></center></div>'
    };

});